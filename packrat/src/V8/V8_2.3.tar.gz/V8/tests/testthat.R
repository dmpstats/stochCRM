library(testthat)
library(V8)

test_check("V8")
