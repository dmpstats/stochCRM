.onLoad <- function(...) {
  as_character_rd <<- make_as_character_rd()
}
