#' @description
#' This roclet is the workhorse of `roxygen`, producing the `.Rd` files that
#' R uses to document that functions, datasets, packages, classes, and
#' other objects.
#'
#' See `vignette("rd")` for details.
