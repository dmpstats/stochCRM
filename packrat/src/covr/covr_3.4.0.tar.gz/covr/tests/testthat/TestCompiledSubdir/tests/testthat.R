library(testthat)
library("TestCompiledSubdir")

test_check("TestCompiledSubdir")
