library(testthat)
library("TestFunctional")

test_check("TestFunctional")
