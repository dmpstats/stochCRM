# See helper-assign.R
test_that("helpers run before tests", {
  expect_equal(abcdefghi, 10)
})
